# My Vercel App

This is a sample Next.js app deployed via GitHub Actions.