export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Hello from Vercel + GitHub Actions!</h1>
      <p>This is a sample Next.js app.</p>
    </div>
  );
}
